import React from "react";
import { SafeAreaView, StyleSheet, TextInput , TouchableOpacity , Text, View} from "react-native";

const UselessTextInput = () => {
  const [text, setText] = React.useState();
  const [frutas, setFruta] = React.useState(["maça", "banana", "figo"])
  const [vazio, setVazio ] = React.useState();

  const addFruta = () =>{
     if (text == ''){
      setVazio("digite algo")
    }else{
    setFruta((f) => [...f, text])
    setText('');
    setVazio('')
  }
  }
  return (
    <SafeAreaView style={styles.container}>
      <TextInput
        style={styles.input}
        onChangeText={setText}
        value={text}
      />
      <Text>{vazio}</Text>
       <TouchableOpacity
        style={styles.button}
        onPress={addFruta}
        
     >
     <Text>Adicionar</Text>
     </TouchableOpacity>

     <View>
     {
       frutas.map((f , i) => <Text key={i}>{f}</Text>)
     }
     </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
   container:{
      margin: 10,
  },
    input: {
    height: 40,
    marginVertical: 10,
    borderWidth: 1,
    padding: 10
    
  },
  button: {
    alignItems: "center",
    marginVertical: 10,
    borderWidth: 1,
    padding: 10,
    backgroundColor: "grey"
    
  }
});

export default UselessTextInput;